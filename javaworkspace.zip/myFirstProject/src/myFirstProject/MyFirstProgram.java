package myFirstProject;

public class MyFirstProgram {

	public static void main(String[] args) {
	
		/*
		작성자 : 이창민
		작성일 : 2024-01-18
		내용 : 문자열 출력 프로그램
		// 아래 코드는 문자 출력 코드입니다.
		 * 
		 */
		System.out.println(/*"Hello */ "world!");
		System.out.println("nana");
		
	}

}
